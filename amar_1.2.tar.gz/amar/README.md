# amar
amar: Adaptive Multiscale AutoRegressive time series models
