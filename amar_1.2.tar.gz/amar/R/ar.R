#' @title Fitting Autoregressive with OLS
#' @description This function fits an autoregressive time series model to the data using the Ordinary Least Squares method to estimate the autoregressive coefficients. It uses a fast implementation.
#' @param x A numeric vector with data points.
#' @param p Order of AR model to fit. 
#' @param use.RcppEigen A logical variable. If \code{use.RcppEigen = TRUE}, the RcppEigen package is used to perform OLS estimation (default, recommended).
#' @param RcppEigen.method An integer specifying method used to solve OLS, see the RcppEigen package.
#' @param ... Other parameters that can be passed to \code{lm.fit} (If \code{use.RcppEigen = FALSE}).
#' @return An object of class "ar.fit", which contains the following fields:
#' \item{response}{The response vector.}
#' \item{p}{Order of the fitted model.}
#' \item{coefficient}{OLS estimates of the autoregressive coefficients.}
#' \item{fitted}{Fitted values.}
#' \item{residuals}{The difference between the response and the fitted value}
#' @export

ar.fit <- function(x, p, use.RcppEigen = TRUE,  RcppEigen.method = 1, ...){
  
  
  x <- as.numeric(x)
  p <- as.integer(p)[1]
  n <- length(x)
  
  use.RcppEigen <- as.logical(use.RcppEigen)

  if(n-p < 1) stop("p has to be lower than length(x)")

  design <- ar.design.matrix(x, p)
  response <- ar.response(x, p)

  
  if(use.RcppEigen == TRUE) tmp <- fastLmPure(design, response, method = RcppEigen.method)
  else tmp <- lm.fit(design, response, ...)
  
  res <- list()
  class(res) <- "ar.fit"
  
  res$response <- response
  res$p <- p
  res$coefficients <- tmp$coefficients
  
  if(p>1) res$fitted <- design %*% res$coefficients
  else res$fitted <- design * res$coefficients

  res$residuals <- response - res$fitted
  
  
  return(res)
  
}



#' @title Create the Design Matrix for AR Model
#' @param x A numeric vector with data points
#' @param order the order for the AR model
#' @export 
#' @useDynLib amar ar_design_matrix
#' @keywords internal


ar.design.matrix <- function(x, order){

  return(.Call("ar_design_matrix", as.numeric(x), as.integer(order)))
  
}


#' @title Create AR Response
#' @export 
#' @param returns an object contains return information
#' @param order the order for the AR model
#' @useDynLib amar ar_response_vector
#' @keywords internal


ar.response <- function(returns, order){
  
  returns <- as.numeric(returns)
  order <- as.integer(order)[1]
  
  return(.Call("ar_response_vector", as.numeric(returns), as.integer(order)))
  
}

