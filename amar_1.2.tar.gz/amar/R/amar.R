#' @title Fitting an AMAR Model with Known Scales
#' @param x A numeric vector with data points
#' @param scales A numeric vector with information about the scales for the AMAR model
#' @param ... Currently not in use.
#' @return An object of class "amar.fit", which contains the following fields:
#' \item{response}{The response vector.}
#' \item{p}{Order of the fitted model.}
#' \item{coefficient}{OLS estimates of the AMAR coefficients.}
#' \item{fitted}{Fitted values.}
#' \item{residuals}{The difference between the response and the fitted value}
#' @export 

amar.fit <- function(x, scales,...){
  
  design <- amar.design.matrix(x, scales)
  response <- amar.response(x, scales)

  tmp <- fastLmPure(design, response, 0)
  
  res <- list()
  class(res) <- "amar.fit"
  
  res$response <- response
  res$scales <- scales
  
  res$residuals <- tmp$residuals
  res$coefficients <- tmp$coefficients
  
  if(length(scales)>1) res$fitted <- design %*% res$coefficients
  else res$fitted <- design * res$coefficients
  return(res)
  
}


#' @title Fitting AMAR Model with Unknown Scales
#' @param x A numeric vector with data points.
#' @param max.order the maximum order allowed for the initial AR fitting
#' @param method the change-point method used scale detection. Default is the narrowest-over-threshold (using the option "not"). Other choices include: "wbs", "wbs2","idetect","tguh". More information regarding these methods can be found in the breakfast R package.
#' @param select criterion used to select the best scales among the candidates. Default option is via the Schwarz Information Criterion (using the option "ic"). 
#' @param max.scales the maximum number of scales allowed for consideration
#' @param verbose when additional information is provided when running the code
#' @param ... currently not in use
#' @return An object of class "amar.fit", which contains the following fields:
#' \item{response}{The response vector.}
#' \item{p}{Order of the fitted model.}
#' \item{coefficient}{OLS estimates of the AMAR coefficients.}
#' \item{fitted}{Fitted values.}
#' \item{residuals}{The difference between the response and the fitted value}
#' @examples 
#' x<-amar.sim(n = 1000, coefficients = c(0.5,0.3), scales = c(1,4))
#' res<-amar(x, max.order=20, max.scales = 10)
#' @export 

amar <- function(x,
                 max.order = min(20,as.integer(sqrt(length(x)))+1),
                 method = "not",
                 select = "ic", 
                 max.scales = 10, verbose=TRUE, ...){
  
  res <- list()
  res$method <- match.arg(method, c("wbs","wbs2","not","idetect","tguh"))
  res$select <- c("ic")
  
  #fit a large AR model
  if(verbose) cat("Computing LSE coefficients for a large AR model.\n")
  res$ar.coefficients <- ar.fit(x, max.order)$coefficients
  
  #detect scales using change-point methods, to get the entire solution path
  if(verbose) cat("Finding scales candidates...\n")
  if(res$method=="wbs") w <- sol.wbs(res$ar.coefficients)
  if(res$method=="wbs2") w <- sol.wbs2(res$ar.coefficients)
  if(res$method=="not") w <- sol.not(res$ar.coefficients)
  if(res$method=="idetect") w <- sol.idetect(res$ar.coefficients)
  if(res$method=="tguh") w <- sol.tguh(res$ar.coefficients)
  
  scales.candidates <- list()
  n.scales.candidates <- 0
  if (w$solutions.nested == FALSE){
    for (j in 1:length(w$solution.set)) if (length(w$solution.set[[j]]) <= max.scales){
      n.scales.candidates <- n.scales.candidates+1
      scales.candidates[[n.scales.candidates]]   <- sort(unique(c(w$solution.set[[j]])))
    }
  } else{
    for (j in 1:length(w$solution.path)) if (j <= max.scales){
      n.scales.candidates <- n.scales.candidates+1
      scales.candidates[[n.scales.candidates]]   <- sort(unique(c(w$solution.path[1:j])))
    }
  }
    
    
  ## for each scale candidate, find the likelihood
    
  ic <- sapply(scales.candidates, function(scales){
    
      tmp <- amar.fit(x/sd(x), scales)
      n <- length(tmp$residuals)
      
      return(n*log(mean(tmp$residuals^2))+ length(scales) * log(n))
      
  })
    
  res$ic <- ic
  res$scales <- scales.candidates[[which.min(ic)]]
  res$scales.candidates <- scales.candidates
  
  
  tmp <- amar.fit(x, res$scales)
  res$response <- tmp$response
  res$fitted <- tmp$fitted
  res$residuals <- tmp$residuals
  res$coefficients <- tmp$coefficients
  
  class(res) <- "amar"
  return(res)
  
}

#' @title Simulate AMAR Model (with Gaussian Noise)
#' @param n a number indicating the length of the time series to be generated.
#' @param coefficients a vector that contains the coefficients corresponding to \code{scales}.
#' @param scales a vector that contains the scales for AMAR.
#' @param sigma the size of the standard error for the noise, default is 1.
#' @examples 
#' x<-amar.sim(n = 1000, coefficients = c(0.5,0.3), scales = c(1,4))
#' @export 

amar.sim <- function(n, coefficients, scales, sigma=1){
  
  scales <- unique(as.integer(scales))
  max.scale <- max(scales)

  x <- ts(rnorm(n+max.scale, 0, sigma), start = 1 - max.scale)
  ar.coefficients <- rep(0, max.scale)
  
  for(j in 1:length(scales)) ar.coefficients[1:scales[j]] <- ar.coefficients[1:scales[j]] + coefficients[j]/scales[j]
  x <- filter(x, ar.coefficients, method = "recursive")
  
  return(x)
  
}


#' @title Create the Design Matrix for AMAR
#' @param x A numeric vector with data points
#' @param scales A numeric vector with information about the scales for the AMAR model
#' @export 
#' @useDynLib amar amar_design_matrix
#' @keywords internal

amar.design.matrix <- function(x, scales){
  
  
  design <- .Call("amar_design_matrix", as.numeric(x), as.integer(sort(setdiff(scales,0))))
  
  if(0 %in% scales) design <- cbind(rep(1, nrow(design)), design)
  
  
  return(design)
  
}


#' @title Create AMAR Response
#' @param returns an object contains return information
#' @param scales A numeric vector with information about the scales for the AMAR model
#' @export 
#' @useDynLib amar amar_response_vector
#' @keywords internal


amar.response <- function(returns, scales){
  
  return(.Call("amar_response_vector", as.numeric(returns),as.integer(sort(scales))))
  
}

